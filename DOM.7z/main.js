const boton = document.querySelector(".playButton button")
const titulo = document.getElementById("titulo")
const intro = document.getElementById("intro")
const seccionDiscurso = document.getElementById("discurso")


let divSprite = document.createElement("div")
let divDiscurso = document.createElement("div")
divSprite.setAttribute("id", "divSprite")
divDiscurso.setAttribute("id", "divDiscurso")
let oakSprite = document.createElement("img")
let texto = document.createElement("p");
oakSprite.src = "./img/oak.png"
texto.setAttribute("id", "texto")

const seleccionPoke = document.getElementById("seleccionPokemon");


boton.onclick = () => {
    titulo.remove()
    intro.remove()
    texto.innerHTML = "¡Hola! Me llamo Oak, soy el profesor en la region de kanto"
    seccionDiscurso.appendChild(divSprite)
    seccionDiscurso.appendChild(divDiscurso)
    divSprite.appendChild(oakSprite)
    divDiscurso.appendChild(texto)
    
}

let formNombre = document.createElement("form")
formNombre.setAttribute("id", "form")
let inputNombre = document.createElement("input")
inputNombre.setAttribute("type", "text")
inputNombre.setAttribute("id", "input")
let submitNombre = document.createElement("input")
submitNombre.setAttribute("type", "submit")
submitNombre.setAttribute("value", "enviar")
let nombreUser;

texto.addEventListener("click", () => {
    texto.innerHTML = "Antes de seguir con tu aventura me gustaria saber tu nombre"
    texto.addEventListener("click", () => {
        texto.remove();
        divDiscurso.appendChild(formNombre)
        formNombre.appendChild(inputNombre)
        formNombre.appendChild(submitNombre)
        formNombre.addEventListener("submit", (e) => {
            e.preventDefault();
            nombre = document.querySelector("#input").value;
            inputNombre.remove()
            submitNombre.remove()
            divDiscurso.appendChild(texto);
            texto.innerHTML = `¡${nombre}, preparate porque tu aventura pokemon esta a punto de empezar!`
            texto.addEventListener("click", () => {
                divSprite.textContent = ""
                divDiscurso.textContent = ""
                seleccionPoke.style.display = "flex"
                seccionDiscurso.style.display = "none"
                
            })
        })
    })
})


/////////////////////////////////////////


class Pokemon{
    constructor(nombre, numero, tipo, ataque, hp, rival, hpMax){
        this.nombre = nombre;
        this.numero = numero;
        this.tipo = tipo;
        this.ataque = ataque;
        this.hp = hp;
        this.rival = rival;
        this.hpMax = hpMax;
    }
}

const bulbasaur = new Pokemon("bulbasaur", 01, "planta", 4, 22, "charmander", 22);
const charmander = new Pokemon("charmander", 04, "fuego", 6, 18, "squirtle", 18);
const squirtle = new Pokemon("squirtle", 07, "agua", 8, 16, "bulbasaur", 16);


/* let descripcion = document.createElement("p");
let bulbasaurSeleccion = document.getElementById("bulbasaur")

descripcion.addEventListener("mouseover", () => {
    bulbasaurSeleccion.appendChild(descripcion)
    descripcion.innerHTML = "Es un sapo planta. seguro lo queres?"
}) */

let descripcionBulba = document.getElementById("descripcionBulbasaur")
let descripcionCharm = document.getElementById("descripcionCharmander")
let descripcionSquir = document.getElementById("descripcionSquirtle")
let bulbasaurSeleccion = document.getElementById("bulbasaur")
let charmanderSeleccion = document.getElementById("bulbasaur")
let squirtleSeleccion = document.getElementById("bulbasaur")

bulbasaurSeleccion.addEventListener("mouseover", () => {
    console.log("wobufeeeet")
    descripcionBulba.innerHTML = "Una rara semilla fue plantada en su espalda al nacer. La planta brota y crece con este Pokémon"
})
bulbasaurSeleccion.addEventListener("mouseout", () =>{
    descripcionBulba.innerHTML = ""
})

charmanderSeleccion.addEventListener("mouseover", () => {
    descripcionCharm.innerHTML = "Prefiere los sitios calientes. Dicen que cuando llueve sale vapor de la punta de su cola."
})
charmanderSeleccion.addEventListener("mouseout", () =>{
    descripcionCharm.innerHTML = ""
})

squirtleSeleccion.addEventListener("mouseover", () => {
    descripcionSquir.innerHTML = "Cuando se esconde en el caparazón, dispara agua a una presión increíble."
})

squirtleSeleccion.addEventListener("mouseout", () =>{
    descripcionSquir.innerHTML = ""
})